﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OxyPlotDemo
{
    public class Data
    {
        public static string[] lines;
        public static string filename;
        public static bool cont = true;
        public static List<Npoint> GetData()
        {
            //var measurements = new List<Measurement>();
            var npoints = new List<Npoint>();
            lines = System.IO.File.ReadAllLines(filename);
                //(@"C:\Users\Emil\Desktop\test_out.txt");
            System.Console.WriteLine("Contents of WriteLines2.txt = ");
            //PointCollection points = new PointCollection();
            //foreach (string line in lines)
            for(int i=0;i<10;i++)
            {
                String line = lines.ElementAt(i);
                String[] data = line.Split(',');
                double y = Convert.ToDouble(data[0]);
                double x = Convert.ToDouble(data[1]);
                npoints.Add(new Npoint(x, y));

                // Use a tab to indent each line of the file.
                Console.WriteLine("\t" + line);
                //Thread.Sleep(200);
            }

            //var startDate = DateTime.Now.AddMinutes(-10);
            //var r = new Random();

            //for (int i = 0; i < 5; i++)
            //{
            //    for (int j = 0; j < 11; j++)
            //    {
            //        measurements.Add(new Measurement() { DetectorId = i, DateTime = startDate.AddMinutes(j), Value = r.Next(1,30) });
            //    }
            //}
            //measurements.Sort((m1,m2)=>m1.DateTime.CompareTo(m2.DateTime));
            //return measurements;
            return npoints;
        }

        //public static List<Measurement> GetUpdateData(DateTime dateTime)
        //{
        //    var measurements = new List<Measurement>();
        //    var r = new Random();

        //    for (int i = 0; i < 5; i++)
        //    {
        //            measurements.Add(new Measurement() { DetectorId = i, DateTime = dateTime.AddSeconds(1), Value = r.Next(1, 30) });
        //    }
        //    return measurements;
        //}

        public static Npoint GetNpoint(int index)
        {
            String line = lines.ElementAt(index);
            String[] data = line.Split(',');
            double y = Convert.ToDouble(data[0]);
            double x = Convert.ToDouble(data[1]);
            return(new Npoint(x, y));
        }
    }

    public class Measurement
    {
        public int DetectorId { get; set; }
        public int Value { get; set; }
        public DateTime DateTime { get; set; }
    }

    public class Npoint
    {
        public double xpoint { get; set; }
        public double ypoint { get; set; }
        public Npoint(double x, double y)
        {
            xpoint = x;
            ypoint = y;
        }
        
    }
}
