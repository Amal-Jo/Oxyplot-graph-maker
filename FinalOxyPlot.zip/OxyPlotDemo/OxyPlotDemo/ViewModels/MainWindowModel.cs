﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using Microsoft.Win32;
using OxyPlot;
using OxyPlot.Axes;
using OxyPlot.Series;
using OxyPlot.Wpf;
using OxyPlotDemo.Annotations;
using LinearAxis = OxyPlot.Axes.LinearAxis;
using LineSeries = OxyPlot.Series.LineSeries;

namespace OxyPlotDemo.ViewModels
{
    public class MainWindowModel:  INotifyPropertyChanged
    {
        private PlotModel plotModel;
        private int index=10;
        public string filename;
        public PlotModel PlotModel
        {
            get { return plotModel; }
            set { plotModel = value; OnPropertyChanged("PlotModel"); }
        }

        private DateTime lastUpdate = DateTime.Now;

        public MainWindowModel()
        {
            PlotModel = new PlotModel();
            SetUpModel();
            LoadData();
        }

        private readonly List<OxyColor> colors = new List<OxyColor>
                                            {
                                                OxyColors.Green,
                                                OxyColors.IndianRed,
                                                OxyColors.Coral,
                                                OxyColors.Chartreuse,
                                                OxyColors.Azure
                                            };

        private readonly List<MarkerType> markerTypes = new List<MarkerType>
                                                   {
                                                       MarkerType.Plus,
                                                       MarkerType.Star,
                                                       MarkerType.Diamond,
                                                       MarkerType.Triangle,
                                                       MarkerType.Cross
                                                   };


        private void SetUpModel()
        {
            PlotModel.LegendTitle = "Temp Reader";
            PlotModel.LegendOrientation = LegendOrientation.Horizontal;
            PlotModel.LegendPlacement = LegendPlacement.Outside;
            PlotModel.LegendPosition = LegendPosition.TopRight;
            PlotModel.LegendBackground = OxyColor.FromAColor(200, OxyColors.White);
            PlotModel.LegendBorder = OxyColors.Black;

            var dateAxis = new LinearAxis(AxisPosition.Bottom,0){ MajorGridlineStyle = LineStyle.Solid, MinorGridlineStyle = LineStyle.Dot, Title = "Timestamp" };
                //new DateTimeAxis(AxisPosition.Bottom, "Date", "HH:mm") { MajorGridlineStyle = LineStyle.Solid, MinorGridlineStyle = LineStyle.Dot, IntervalLength = 80 };
            PlotModel.Axes.Add(dateAxis);
            var valueAxis = new LinearAxis(AxisPosition.Left, 0) { MajorGridlineStyle = LineStyle.Solid, MinorGridlineStyle = LineStyle.Dot, Title = "Temperature in degree C" };
            PlotModel.Axes.Add(valueAxis);

        }

        private void LoadData()
        {

            List<Npoint> npoints = Data.GetData();
            //
            //List<Measurement> measurements = Data.GetData();

            //var dataPerDetector = measurements.GroupBy(m => m.DetectorId).OrderBy(m=>m.Key).ToList();

            //foreach (var data in dataPerDetector)
            var lineSerie = new LineSeries
            {
                StrokeThickness = 2,
                MarkerSize = 3,
                MarkerStroke = OxyColors.Black,
                //MarkerType = markerTypes[data.Key],
                CanTrackerInterpolatePoints = false,
                //Title = string.Format("Detector {0}", data.Key),
                Smooth = false,
            };
            lineSerie.Points.Add(new DataPoint(0, 0));
            foreach (Npoint np in npoints)
            {
                
                lineSerie.Points.Add(new DataPoint(np.xpoint, np.ypoint));

                //    data.ToList().ForEach(d=>lineSerie.Points.Add(new DataPoint(DateTimeAxis.ToDouble(d.DateTime),d.Value)));
                    
            }
            PlotModel.Series.Add(lineSerie);
            //lastUpdate = DateTime.Now;
        }

        public void UpdateModel()
        {
            System.Console.WriteLine("Index {0}", index);
            if (index < (Data.lines.Length))
            {
                //List<Measurement> measurements = Data.GetUpdateData(lastUpdate);
                Npoint point = Data.GetNpoint(index);
                //var dataPerDetector = measurements.GroupBy(m => m.DetectorId).OrderBy(m => m.Key).ToList();
                System.Console.WriteLine("Series {0}", PlotModel.Series.Count);
                //foreach (var data in dataPerDetector)
                // {
                var lineSerie = PlotModel.Series[0] as LineSeries;
                if (lineSerie != null)
                {
                    //data.ToList()
                    //.ForEach(d => lineSerie.Points.Add(new DataPoint(DateTimeAxis.ToDouble(d.DateTime), d.Value)));
                    lineSerie.Points.Add(new DataPoint(point.xpoint, point.ypoint));
                }
                else
                {
                    System.Console.WriteLine("NULL At LineSerie");
                }
                //lastUpdate = DateTime.Now;
                index++;
            }
            else
            {
                Data.cont = false;
            }
        }

        public bool saveFile()
        {
            var sfd = new SaveFileDialog();
            var directory = Path.GetDirectoryName(Data.filename) ?? ".";
            sfd.InitialDirectory = directory;
            sfd.Filter = "PNG files (*.png)|*.png|All files (.*)|*.*";
            sfd.FilterIndex = 0;
            sfd.RestoreDirectory = true;

            if (sfd.ShowDialog() == true)
            {

                PngExporter.Export(plotModel, sfd.FileName, 525, 300, OxyColors.White);
                return true;
            }
            return false;
        }


        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
