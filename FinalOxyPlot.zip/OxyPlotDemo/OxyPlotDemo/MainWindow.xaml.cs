﻿using Microsoft.Win32;
using OxyPlot;
using OxyPlot.Wpf;
using System;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Media;

namespace OxyPlotDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    public partial class MainWindow : Window
    {

        private ViewModels.MainWindowModel viewModel;

        public MainWindow()
        {
            //viewModel = new ViewModels.MainWindowModel();
            //DataContext = viewModel;

            //CompositionTarget.Rendering += CompositionTargetRendering;
            //stopwatch.Start();

            InitializeComponent();
            BtnSaveGraph.IsEnabled = false;
        }

        private long frameCounter;
        private System.Diagnostics.Stopwatch stopwatch = new Stopwatch();
        private long lastUpdateMilliSeconds;
        //private long index = 10;

        private void CompositionTargetRendering(object sender, EventArgs e)
        {
            if (Data.cont)
            {
                if (stopwatch.ElapsedMilliseconds > lastUpdateMilliSeconds + 200)
                {
                    viewModel.UpdateModel();
                    Plot1.RefreshPlot(true);
                    lastUpdateMilliSeconds = stopwatch.ElapsedMilliseconds;
                }
            }
            else
            {
                stopwatch.Stop();
            }
        }

        private void SelFileBtnClick(object sender, RoutedEventArgs e)
        {
            //PngExporter.Export(this.PlotModel, stream, 800, 600);

            OpenFileDialog ff = new OpenFileDialog();

            ff.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop); //"C:\\";
            ff.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            ff.Multiselect = true;
            ff.FilterIndex = 1;
            ff.RestoreDirectory = true;
            if (ff.ShowDialog() == true)
            {
                try
                {
                    foreach (String file in ff.FileNames) //if ((myStream = ff.OpenFile()) != null)
                    {
                        ///path = file;
                        Data.filename = file;
                        System.Console.WriteLine(file);

                    }

                    viewModel = new ViewModels.MainWindowModel();
                    //System.Console.WriteLine("Path:",path);
                    //Data.filename = path;
                    DataContext = viewModel;

                    CompositionTarget.Rendering += CompositionTargetRendering;
                    stopwatch.Start();
                }
                catch (Exception err)
                {
                    //Inform the user if we can't read the file
                    MessageBox.Show(err.Message);
                }
                BtnSelFile.Content = "File selected";
                BtnSelFile.IsEnabled = false;
                BtnSaveGraph.IsEnabled = true;
            }
        }

        private void saveFileBtnClick(object sender, RoutedEventArgs e)
        {
            if (viewModel.saveFile()) { MessageBox.Show("File saved successfully"); }
        }
    }
}
